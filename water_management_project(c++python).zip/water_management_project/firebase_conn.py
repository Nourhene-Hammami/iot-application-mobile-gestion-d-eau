import firebase_admin 
from firebase_admin import credentials, db
import serial 
import time
import re

# Set up the serial connection to Arduino
ser = serial.Serial('COM6', 9600, timeout=1)  # Adjust COM port and baud rate according to your Arduino

# Initialize Firebase credentials and database URL
cred = credentials.Certificate("water-cee9a-firebase-adminsdk-yjlfs-964c5b740e.json")
firebase_admin.initialize_app(cred, {'databaseURL': 'https://water-cee9a-default-rtdb.firebaseio.com'})

# Get a reference to the database service
ref = db.reference('/')

while True:
    # Read data from Arduino
    data = ser.readline().decode().strip()
    
    print("Received data from Arduino:", data)  # Print the received data

    # Use regular expressions to extract numeric values for each field
    humidity_match = re.search(r'humidity:\s*([\d.]+)%', data)
    temp_match = re.search(r'temperature:\s*([\d.]+)°C', data)
    level_match = re.search(r'waterLevel:\s*([\d.]+)', data)
    ph_match = re.search(r'ph:\s*([\d.]+)', data)
    turbidity_match = re.search(r'turbidity:\s*([\d.]+)', data)

    # Create a dictionary to store sensor readings
    data_dict = {}

    # Assign values to respective keys if matches are found
    if humidity_match:
        data_dict['humidity'] = float(humidity_match.group(1))
    if temp_match:
        data_dict['temperature'] = float(temp_match.group(1))
    if level_match:
        data_dict['waterLevel'] = float(level_match.group(1))
    if ph_match:
        data_dict['ph'] = float(ph_match.group(1))
    if turbidity_match:
        data_dict['turbidity'] = float(turbidity_match.group(1))

    # Push data to Firebase
    if data_dict:  # Check if there's any data to update
        ref.update(data_dict)

    time.sleep(1)  # Adjust the delay as needed
